#!/bin/sh

# support for fancy charactersets! :)
sed s/λ/lambda/g $1 | \
sed s/Ω/omega/g     | \
sed s/→/\.arrow/g   | \
/Users/antoine/External/SeaMonkey.app/Contents/MacOS/xpcshell

# /Users/antoine/External/SeaMonkey.app/Contents/MacOS/xpcshell $1


